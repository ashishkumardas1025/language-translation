# Canadian French Document Translator

## Overview

The **Canadian French Document Translator** is a web application that uses AI to translate documents into authentic Canadian French. It ensures that the translations preserve the original document's structure, formatting, and terminology, with a focus on Canadian French expressions and technical banking terms.

## Features

- **Document Translation**: Upload `.txt`, `.docx`, or `.doc` files and translate them into Canadian French.
- **Translation Validation**: Compare the AI-generated translation with a reference Canadian French document to assess accuracy.
- **Progress Tracking**: Visual progress bar to track the translation process.
- **Download Options**: Download translated documents in `.txt` or `.docx` formats.
- **Authenticity Scoring**: Evaluate the Canadian French authenticity of the translation.
- **Keyword and Semantic Analysis**: Analyze the translation's accuracy using statistical and semantic metrics.

## How to Run the Application

1. **Install Dependencies**:
   ```bash
   npm install

2. Run the Development Server
    npm start
    The application will be available at http://localhost:4200.

3. Build for Production
    npm run build

## Technologies Used
Angular 17: Framework for building the application.
TypeScript: Strongly typed programming language.
SCSS: Styling with variables and reusable components.
RxJS: Reactive programming for handling asynchronous operations.

## Components
1. Document Translator
Upload documents and translate them into Canadian French.
Displays translation progress and allows downloads.
2. Translation Validator
Compare AI-generated translations with reference documents.
Provides statistical and semantic analysis of the translation.
3. Progress Bar
Visual indicator for tracking translation progress.
4. File Uploader
Handles file selection for translation and validation.
5. Download Link
Generates download links for translated documents.

## Services
Translation Service: Handles translation logic, API calls, and accuracy validation.

## Models
Translation Models: Defines data structures for translation results, accuracy metrics, and semantic assessments.

## License
This project is licensed under the MIT License.

