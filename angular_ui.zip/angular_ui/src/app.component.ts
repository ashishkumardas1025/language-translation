import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentTranslatorComponent } from './components/document-translator/document-translator.component';
import { TranslationValidatorComponent } from './components/translation-validator/translation-validator.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    DocumentTranslatorComponent,
    TranslationValidatorComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  activeTab = 'translate'; // 'translate' or 'validate'
  
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
}