import { Routes } from '@angular/router';
import { DocumentTranslatorComponent } from './document-translator/document-translator.component';
import { TranslationValidatorComponent } from './translation-validator/translation-validator.component';

export const routes: Routes = [
  { path: '', redirectTo: 'translate', pathMatch: 'full' },
  { path: 'translate', component: DocumentTranslatorComponent },
  { path: 'validate', component: TranslationValidatorComponent },
  { path: '**', redirectTo: 'translate' } // Fallback route
];