import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FileUploaderComponent } from '../file-uploader/file-uploader.component';
import { ProgressBarComponent } from '../progress-bar/progress-bar.component';
import { DownloadLinkComponent } from '../download-link/download-link.component';
import { TranslationService } from '../../services/translation.service';
import { TranslationResult } from '../../models/translation.model';

@Component({
  selector: 'app-document-translator',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    FileUploaderComponent,
    ProgressBarComponent,
    DownloadLinkComponent
  ],
  templateUrl: './document-translator.component.html',
  styleUrls: ['./document-translator.component.scss']
})
export class DocumentTranslatorComponent {
  originalText = '';
  translatedText = '';
  originalFileName = '';
  isTranslating = false;
  progressValue = 0;
  translationResult: TranslationResult | null = null;
  txtDownloadUrl = '';
  docxDownloadUrl = '';
  showOriginalContent = true;
  
  constructor(private translationService: TranslationService) {}
  
  async onFileSelected(file: File): Promise<void> {
    this.originalFileName = file.name;
    try {
      this.originalText = await this.translationService.extractTextFromFile(file);
    } catch (error) {
      console.error('Error reading file:', error);
      // Handle error appropriately
    }
  }
  
  translate(): void {
    if (!this.originalText) {
      return;
    }
    
    this.isTranslating = true;
    this.progressValue = 0;
    
    // Simulate progress steps
    const progressInterval = setInterval(() => {
      if (this.progressValue < 75) {
        this.progressValue += 25;
      }
    }, 700);
    
    this.translationService.processDocumentForQuebecFrench(this.originalText)
      .subscribe({
        next: (result) => {
          clearInterval(progressInterval);
          this.progressValue = 100;
          this.translationResult = result;
          this.translatedText = result.translated_text;
          
          // Create download URLs
          this.txtDownloadUrl = this.translationService.createDownloadLink(
            result.translated_text,
            `${this.originalFileName.split('.')[0]}_quebec_french.txt`
          );
          this.docxDownloadUrl = this.translationService.createDownloadLink(
            result.translated_text,
            `${this.originalFileName.split('.')[0]}_quebec_french.docx`
          );
          
          // Store in session/local storage for validator component
          localStorage.setItem('translatedText', result.translated_text);
          localStorage.setItem('originalText', this.originalText);
          localStorage.setItem('fileName', this.originalFileName);
          
          this.isTranslating = false;
        },
        error: (err) => {
          clearInterval(progressInterval);
          console.error('Translation error:', err);
          this.isTranslating = false;
          // Handle error appropriately
        }
      });
  }
  
  toggleOriginalContent(): void {
    this.showOriginalContent = !this.showOriginalContent;
  }
}