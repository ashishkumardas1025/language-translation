import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-download-link',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './download-link.component.html',
  styleUrls: ['./download-link.component.scss']
})
export class DownloadLinkComponent {
  @Input() url = '';
  @Input() filename = '';
  @Input() label = 'Download';
}
