import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FileUploaderComponent } from '../file-uploader/file-uploader.component';
import { TranslationService } from '../../services/translation.service';
import { AccuracyMetrics, SemanticAssessment } from '../../models/translation.model';

@Component({
  selector: 'app-translation-validator',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    FileUploaderComponent
  ],
  templateUrl: './translation-validator.component.html',
  styleUrls: ['./translation-validator.component.scss']
})
export class TranslationValidatorComponent implements OnInit {
  translatedText = '';
  referenceText = '';
  isLoading = false;
  hasTranslatedText = false;
  
  // Analysis results
  statisticalAccuracy: AccuracyMetrics | null = null;
  semanticAssessment: SemanticAssessment | null = null;
  
  // Tab control
  activeTab = 'semantic'; // 'semantic' or 'statistical'
  
  constructor(private translationService: TranslationService) {}
  
  ngOnInit(): void {
    // Check if we have a translated text from the translator component
    const savedTranslation = localStorage.getItem('translatedText');
    if (savedTranslation) {
      this.translatedText = savedTranslation;
      this.hasTranslatedText = true;
    }
  }
  
  async onReferenceFileSelected(file: File): Promise<void> {
    try {
      this.referenceText = await this.translationService.extractTextFromFile(file);
      if (this.hasTranslatedText && this.referenceText) {
        this.analyzeTranslation();
      }
    } catch (error) {
      console.error('Error reading reference file:', error);
      // Handle error appropriately
    }
  }
  
  analyzeTranslation(): void {
    if (!this.translatedText || !this.referenceText) {
      return;
    }
    
    this.isLoading = true;
    
    // Get statistical accuracy
    this.translationService.calculateKeywordAccuracy(this.translatedText, this.referenceText)
      .subscribe({
        next: (result) => {
          this.statisticalAccuracy = result;
        },
        error: (err) => {
          console.error('Error calculating keyword accuracy:', err);
          // Handle error appropriately
        }
      });
    
    // Get semantic assessment
    this.translationService.assessSemanticAccuracy(this.translatedText, this.referenceText)
      .subscribe({
        next: (result) => {
          this.semanticAssessment = result;
          this.isLoading = false;
        },
        error: (err) => {
          console.error('Error assessing semantic accuracy:', err);
          this.isLoading = false;
          // Handle error appropriately
        }
      });
  }
  
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
}