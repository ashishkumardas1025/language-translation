export interface TranslationResult {
    translated_text: string;
    quality_review?: {
      quebec_french_authenticity?: number;
    };
    error?: string;
    stage?: string;
  }
  
  export interface AccuracyMetrics {
    overlap_percentage: number;
    cosine_similarity: number;
    common_words: number;
    reference_words: number;
    important_keywords: string[];
  }
  
  export interface SemanticAssessment {
    semantic_accuracy_score: number;
    quebec_french_authenticity_comparison: number;
    fluency_comparison: number;
    terminology_consistency_score: number;
    error?: string;
  }
  
  export interface BankingTerms {
    [key: string]: string;
  }