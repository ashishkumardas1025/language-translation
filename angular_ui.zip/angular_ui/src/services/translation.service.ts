import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TranslationResult, AccuracyMetrics, SemanticAssessment, BankingTerms } from '../models/translation.model';

@Injectable({
  providedIn: 'root'
})
export class TranslationService {
  // Default banking terms - hardcoded as in the original app
  private bankingTerms: BankingTerms = {
    "help": "aide",
    "sign out": "quitter",
    "account": "compte",
    "balance": "solde",
    "transfer": "virement",
    "deposit": "dépôt",
    "withdrawal": "retrait",
    "credit card": "carte de crédit",
    "debit card": "carte de débit"
  };

  constructor(private http: HttpClient) { }

  // In a real application, these would call API endpoints
  // For now, we'll simulate the behavior with mock data
  
  processDocumentForQuebecFrench(textContent: string): Observable<TranslationResult> {
    // Simulating API call with delay
    const mockResult: TranslationResult = {
      translated_text: this.mockTranslate(textContent),
      quality_review: {
        quebec_french_authenticity: 8.5
      }
    };
    
    // Simulate delay of API call
    return of(mockResult).pipe(delay(2000));
  }
  
  calculateKeywordAccuracy(generatedText: string, referenceText: string): Observable<AccuracyMetrics> {
    // Mock implementation of keyword accuracy calculation
    const mockAccuracy: AccuracyMetrics = {
      overlap_percentage: 78.5,
      cosine_similarity: 82.3,
      common_words: 245,
      reference_words: 312,
      important_keywords: [
        "compte", "solde", "virement", "dépôt", "retrait",
        "transaction", "bancaire", "économies", "intérêt", "crédit",
        "débit", "paiement", "hypothèque", "assurance", "épargne",
        "placement", "investissement", "portefeuille", "bénéfice", "banque"
      ]
    };
    
    return of(mockAccuracy).pipe(delay(1500));
  }
  
  assessSemanticAccuracy(
    translatedText: string, 
    referenceText: string
  ): Observable<SemanticAssessment> {
    // Mock implementation of semantic assessment
    const mockAssessment: SemanticAssessment = {
      semantic_accuracy_score: 8.2,
      quebec_french_authenticity_comparison: 7.9,
      fluency_comparison: 8.5,
      terminology_consistency_score: 8.7
    };
    
    return of(mockAssessment).pipe(delay(2500));
  }
  
  // Helper method to extract text from files
  extractTextFromFile(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target?.result) {
          // For simplicity, we're treating all files as text
          // In a real app, you'd parse docx files differently
          resolve(event.target.result as string);
        } else {
          reject('Error reading file');
        }
      };
      
      reader.onerror = () => {
        reject('Error reading file');
      };
      
      reader.readAsText(file);
    });
  }
  
  // Simple mock translation (just for demo purposes)
  private mockTranslate(text: string): string {
    // Very simple mock translation that just adds some Quebec phrases
    const quebecPhrases = [
      "Tabarnak! ",
      "Osti de ",
      "C'est ben l'fun! ",
      "Chu ",
      "Toé, ",
      "C'est de valeur... "
    ];
    
    // Replace some banking terms
    let translated = text;
    Object.keys(this.bankingTerms).forEach(term => {
      const regex = new RegExp(`\\b${term}\\b`, 'gi');
      translated = translated.replace(regex, this.bankingTerms[term]);
    });
    
    // Add a Quebec phrase at the beginning
    const randomPhrase = quebecPhrases[Math.floor(Math.random() * quebecPhrases.length)];
    translated = randomPhrase + translated;
    
    return translated;
  }
  
  // Create download links
  createDownloadLink(content: string, filename: string): string {
    const blob = new Blob([content], { type: 'text/plain' });
    return URL.createObjectURL(blob);
  }
}